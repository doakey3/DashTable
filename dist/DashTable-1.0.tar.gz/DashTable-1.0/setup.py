from distutils.core import setup

setup(name='DashTable',
      version='1.0',
      author='Gustav Klopp',
      author_email='gustavk@protonmail.com',
      url='https://github.com/gustavklopp/DashTable',
      packages=['DashTable'],
)